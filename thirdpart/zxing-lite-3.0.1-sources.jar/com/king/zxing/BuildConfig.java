/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.king.zxing;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.king.zxing";
  public static final String BUILD_TYPE = "release";
}
